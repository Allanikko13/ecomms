<?php

session_destroy();
echo "<script>
            alert('Account Logout');
            // window.location.href='login.php';

            </script>";
// header("Location: index.php");


?>