<?php session_start();
  require "connect.php";


    if(isset($_POST['btn_reg'])){
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $confirmpass = $_POST['confirmpass'];
        echo $user;
        echo $pass;
        echo $confirmpass;

        $sql = "INSERT INTO tbl_login(user, pass, confirmpass) VALUES('$user','$pass','$confirmpass')";
        
        
        $q = mysqli_query($conn, $sql);

          if ($q){
            echo "<script>
            alert('Registered Successfully');
            window.location.href='login.php';
            </script>";
          }
      }
	  
  if(isset($_POST['btn_login']))
	 {
		$user = $_POST['user'];
        $pass = $_POST['pass'];
        $sql = "SELECT * FROM tbl_login WHERE user = '$user' AND pass = '$pass'";
		 $q = mysqli_query($conn, $sql);
        $r = mysqli_num_rows($q);

        if($r > 0){
            $_SESSION['login'] = true;
          echo "<script>
          alert('Login Successfully');
          window.location.href='home.php';
          </script>";
        }
        else{
          echo "<script>
          alert('Invalid Username or password');
          window.location.href='login.php';
          </script>";
        }
      
	 }
   ?>